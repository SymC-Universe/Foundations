import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os

# ==========================================
# CRITICAL FOR ILLUSTRATOR EDITABILITY
# ==========================================
plt.rcParams['svg.fonttype'] = 'none'
plt.rcParams['font.family'] = 'sans-serif'

# ── Cosmological parameters ──────────────────────────────────────────────────
Omega_m0 = 0.315  
Omega_L0 = 0.685

# ── Helper Functions ─────────────────────────────────────────────────────────
def get_cosmology(z, w=-1.0):
    E2 = Omega_m0*(1+z)**3 + Omega_L0*(1+z)**(3*(1+w))
    Om_z = (Omega_m0*(1+z)**3) / E2
    ODE_z = (Omega_L0*(1+z)**(3*(1+w))) / E2
    q_z = 0.5*Om_z + 0.5*(1 + 3*w)*ODE_z
    chi_z = 1.0 / np.sqrt(1.5 * Om_z)
    return q_z, chi_z

z_arr = np.linspace(3.0, -0.8, 1000)

q_lcdm, chi_lcdm = get_cosmology(z_arr, w=-1.0)
z_sync_lcdm = 0.63

q_w8, chi_w8 = get_cosmology(z_arr, w=-0.8)   
q_w12, chi_w12 = get_cosmology(z_arr, w=-1.2) 

# ── Figure layout ────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(12, 5.0))
fig.patch.set_facecolor('white')

plt.subplots_adjust(top=0.88, bottom=0.12, left=0.06, right=0.94, wspace=0.32)
gs = gridspec.GridSpec(1, 2, figure=fig)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PANEL a  — Temporal Phase Transition
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ax1  = fig.add_subplot(gs[0])
ax1r = ax1.twinx()

ax1.plot(z_arr, q_lcdm, color='#4CA3DD', lw=2.6, zorder=3)
ax1.axhline(0, color='#4CA3DD', lw=0.8, ls=':', alpha=0.45)

ax1r.plot(z_arr, chi_lcdm, color='#C0266E', lw=2.6, ls='--', zorder=3)
ax1r.axhline(1, color='#C0266E', lw=0.8, ls=':', alpha=0.45)

ax1.axvline(z_sync_lcdm, color='#333333', lw=1.3, ls=':')

# Atomic Text Elements
ax1.text(z_sync_lcdm + 0.09, -0.66, 'Synchronization', fontsize=9, color='#333333', va='center')
ax1.text(z_sync_lcdm + 0.09, -0.78, f'z = {z_sync_lcdm}', fontsize=9, color='#333333', va='center')

# Pure Unicode text for labels
ax1.text(1.5, 0.35, 'q(z)', color='#4CA3DD', fontsize=12, fontweight='bold')
ax1.text(0.1, 4.0, 'χ_δ(z)', color='#C0266E', fontsize=12, fontweight='bold')

ax1.axvspan(-0.5, z_sync_lcdm, alpha=0.06, color='#C0266E', zorder=0)

ax1.set_xlim(2.6, -0.55)
ax1.set_ylim(-1.08, 0.60)
ax1r.set_ylim(0.5, 9.5)

ax1.set_xlabel('Redshift z (Lookback Time)', fontsize=11)
ax1.set_ylabel('Deceleration parameter q', color='#4CA3DD', fontsize=11)
ax1r.set_ylabel('Stability Index (χ)', color='#C0266E', fontsize=11)
ax1.tick_params(axis='y', labelcolor='#4CA3DD')
ax1r.tick_params(axis='y', labelcolor='#C0266E')

ax1.scatter([z_sync_lcdm], [0], color='black', s=55, zorder=6)
ax1.set_title('a.  Temporal Phase Transition', fontsize=13, fontweight='bold', loc='left', pad=10)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PANEL b  — THE NEW STRUCTURAL IDENTITY PHASE SPACE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ax2 = fig.add_subplot(gs[1])

ax2.axvline(1.0, color='#C0266E', lw=1.5, ls='-', alpha=0.3, zorder=1)
ax2.axhline(0.0, color='#4CA3DD', lw=1.5, ls='-', alpha=0.3, zorder=1)

ax2.plot(chi_lcdm, q_lcdm, color='#333333', lw=3, zorder=4)

ax2.plot(chi_w8, q_w8, color='#888888', lw=1.5, ls='--', alpha=0.6, zorder=2)
ax2.plot(chi_w12, q_w12, color='#888888', lw=1.5, ls='--', alpha=0.6, zorder=2)

ax2.annotate('', xy=(chi_lcdm[-200], q_lcdm[-200]), xytext=(chi_lcdm[-300], q_lcdm[-300]),
            arrowprops=dict(arrowstyle="->", color='#333333', lw=2), zorder=5)

ax2.scatter([1.0], [0.0], color='gold', edgecolor='black', s=200, marker='*', zorder=10)

# ── ATOMIC TEXT ELEMENTS FOR PANEL B (MATH-FREE UNICODE) ──

ax2.text(1.03, 0.05, 'Exact Identity Crossing', fontsize=11, fontweight='bold', zorder=11)
# Pure Unicode string - no giant MathText bounding box!
ax2.text(1.03, 0.00, '(χ_δ = 1 ⇔ q = 0)', color='black', fontsize=10, zorder=11)

# Pure Unicode string for Lambda
ax2.text(0.85, 0.25, 'Flat ΛCDM', fontsize=11, fontweight='bold', color='#333333', rotation=-48)

# Standard strings for the rest
ax2.text(1.2, 0.18, 'w = -0.8', fontsize=9, color='#888888')
ax2.text(1.2, -0.40, 'w = -1.2', fontsize=9, color='#888888')

ax2.text(0.82, 0.50, 'Matter Dominated\n(Underdamped)', fontsize=9, color='grey', ha='center', style='italic')
ax2.text(1.65, -0.85, 'Dark Energy Dominated\n(Overdamped)', fontsize=9, color='grey', ha='center', style='italic')

# Axes setup
ax2.set_xlim(0.75, 1.8)
ax2.set_ylim(-1.0, 0.6)
# Pure unicode for axes labels too
ax2.set_xlabel('Stability Index (χ_δ)', fontsize=12)
ax2.set_ylabel('Deceleration Parameter (q)', fontsize=12)
ax2.set_title('b.  Structural Identity Trajectory', fontsize=13, fontweight='bold', loc='left', pad=10)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
output_file = 'Fig2_Synchronization.svg'
plt.savefig(output_file, facecolor='white')

# Force the image to actually display on your screen!
plt.show()

# Tell you exactly where it was saved so you don't have to go hunting
if os.path.exists(output_file):
    print(f"\nSUCCESS: Your file is saved right here:")
    print(os.path.abspath(output_file))
else:
    print("\nERROR: For some reason, the file didn't save.")